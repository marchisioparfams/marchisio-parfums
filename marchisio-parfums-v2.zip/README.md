# Marchisio Parfums — Guía del cliente

## ¿Cómo abrir la web para verla?
Hacé doble clic en `index.html`. Se abre en tu navegador.

## ¿Cómo subir a Hostinger?
1. Entrá al panel de Hostinger
2. File Manager → public_html
3. Arrastrá los archivos: `index.html`, `styles.css`, `main.js`
4. ¡Listo!

## ¿Cómo cambiar el número de WhatsApp?
1. Abrí `index.html` con el Bloc de notas
2. Ctrl+H (buscar y reemplazar)
3. Buscá: `5491112345678`
4. Reemplazá por tu número: `549 + código de área + número` (sin el 0 y sin el 15)
   - Ejemplo: si tu número es 011-5555-1234 → `5491155551234`
5. Hacé clic en "Reemplazar todo" → Guardá (Ctrl+S)

## ¿Cómo cambiar el Instagram?
En `index.html`, buscá (Ctrl+F) `marchisioparfums` y reemplazalo con tu usuario real.

## ¿Cómo agregar un producto nuevo?

### Perfume:
Copiá este bloque y pegalo dentro del `<div id="perfumes-grid">`:

```html
<div class="perfume-card" data-tags="mini30 femenino">
  <div class="card-img-wrap">
    <div class="card-img-placeholder" style="--c1:#2a001a;--c2:#0a0008;">
      <div class="card-img-brand">NOMBRE MARCA</div>
    </div>
    <div class="card-badge-formato">Mini 30ml</div>
    <div class="card-badge-gender">Femenino</div>
  </div>
  <div class="card-body">
    <div class="card-marca">MARCA</div>
    <h3 class="card-nombre">NOMBRE PERFUME</h3>
    <p class="card-familia">Familia olfativa</p>
    <p class="card-desc">Descripción del perfume.</p>
    <div class="card-footer">
      <div class="card-price">$PRECIO</div>
      <a href="https://wa.me/5491112345678?text=Hola!%20Quiero%20el%20NOMBRE" target="_blank" class="btn-comprar">Consultar →</a>
    </div>
  </div>
</div>
```

Para los `data-tags`, combiná: `tubito`, `mini30`, `mini50`, `splash`, `deo`, `masculino`, `femenino`, `unisex`

## ¿Algo no se actualiza?
Presioná Ctrl+F5 en el navegador, o abrí en modo incógnito.

---
¡Éxito con el emprendimiento! 🌸
